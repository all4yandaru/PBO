public interface Seleksi {
    float hitungRataRata();
    void hasil();
}
